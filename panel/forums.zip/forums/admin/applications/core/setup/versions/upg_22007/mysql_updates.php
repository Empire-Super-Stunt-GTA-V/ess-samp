<?php
/*
+--------------------------------------------------------------------------
|   IP.Board v3.4.8
|   ========================================
|   by Matthew Mecham
|   (c) 2001 - 2004 Invision Power Services
|
|   ========================================
|
|
|
+---------------------------------------------------------------------------
*/


# Nothing of interest!

// $SQL[] = "";

$SQL[] = "DELETE FROM conf_settings_titles WHERE conf_title_keyword='httpapi';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='emo_per_row';";

