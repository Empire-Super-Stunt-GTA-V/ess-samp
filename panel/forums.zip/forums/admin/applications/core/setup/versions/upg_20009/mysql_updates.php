<?php
/*
+--------------------------------------------------------------------------
|   IP.Board v3.4.8
|   ========================================
|   by Matthew Mecham
|   (c) 2001 - 2004 Invision Power Services
|
|   ========================================
|
|
|
+---------------------------------------------------------------------------
*/

$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('P_UP', '<img src=\'style_images/<#IMG_DIR#>/p_up.gif\' border=\'0\'  alt=\'Go to the top of the page\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('P_CARD', '<img src=\'style_images/<#IMG_DIR#>/p_card.gif\' border=\'0\'  alt=\'Profile Card\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('PRO_AIM', '<img src=\'style_images/<#IMG_DIR#>/profile_aim.gif\' border=\'0\'  alt=\'AIM\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('PRO_ITEM', '<img src=\'style_images/<#IMG_DIR#>/profile_item.gif\' border=\'0\'  alt=\'Profile Item\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('PRO_MSN', '<img src=\'style_images/<#IMG_DIR#>/profile_msn.gif\' border=\'0\'  alt=\'MSN\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('PRO_ICQ', '<img src=\'style_images/<#IMG_DIR#>/profile_icq.gif\' border=\'0\'  alt=\'ICQ\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('PRO_YIM', '<img src=\'style_images/<#IMG_DIR#>/profile_yahoo.gif\' border=\'0\'  alt=\'Yahoo\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('PRO_CONTACT', '<img src=\'style_images/<#IMG_DIR#>/icon_msg_nonew.gif\' border=\'0\'  alt=\'Contact\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('BAR_LEFT', '<img src=\'style_images/<#IMG_DIR#>/bar_left.gif\' border=\'0\'  alt=\'*\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('BAR_RIGHT', '<img src=\'style_images/<#IMG_DIR#>/bar_right.gif\' border=\'0\'  alt=\'*\' />', 1, 1);";
$SQL[] = "INSERT INTO skin_macro (macro_value, macro_replace, macro_can_remove, macro_set) VALUES ('CAL_GOTO', '<img src=\'style_images/<#IMG_DIR#>/cal_goto.gif\' border=\'0\'  alt=\'Goto Month\' />', 1, 1);";
